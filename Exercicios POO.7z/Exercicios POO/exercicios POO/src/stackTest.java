import java.util.Scanner;

public class StackTest {
	
    public static void main(String[] args) {
		
        Stack<aluno> a = new ObjectStack<>();

        a.push(new aluno(1, "Felipe", 21));
		
        a.push(new aluno(2, "Rodrigo", 22));
		
        a.push(new aluno(3, "Lucas", 23));

        try { 
            System.out.println(a.pop());
			
            System.out.println(a.pop());
			
            System.out.println(a.pop());
			
            System.out.println(a.pop());
			
        } catch (IndexOutOfBoundsException ex) { 
		
		
            System.out.println(ex.getMessage());
			
			
        }
		
        System.out.println("End!");
    }
}