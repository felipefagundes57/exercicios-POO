public interface Stack<T> {
	
    void push(T data);
	
    boolean isEmpty();
	
	P pop();
}